# BérKalkulátor Android alkalmazás

A projekt a korábbi Excel bérkalkulátor mobilos változata. Natív Android/Java, külső UI-könyvtár nélkül.

Fő funkciók:
- alapbér, havi munkaóra, délelőttös/délutános napok
- 30%-os délutáni pótlék
- túlóra órában és percben
- bónusz
- bejárási támogatás
- 3 gyermekes családi kedvezmény
- bruttó/nettó és teljes utalás
- 1 vagy több letiltás becslése
- az utoljára megadott adatok automatikus mentése a telefonon

## Telepíthető APK készítése
Nyisd meg a mappát Android Studio-ban, majd **Build > Build APK(s)**.
A létrejött APK telepíthető Android telefonra.
